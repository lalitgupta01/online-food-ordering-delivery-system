function Register() {
    return ( <>
    
    
    </> );
    
}

export default Register;
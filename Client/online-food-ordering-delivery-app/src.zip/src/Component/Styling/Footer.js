function Footer() {
    return (
    <>
        <nav className="navbar" style={{backgroundColor : "#333333", height : "7vh",marginTop : "7vh" }}>
            <div className="container-fluid">
                <a className="navbar-brand" href="#" style={{color : "#FFFFFF",fontSize: "2.5vh",marginRight : "5vh"}}>Copyright</a>
            </div>
        </nav>
    </>);
}

export default Footer;